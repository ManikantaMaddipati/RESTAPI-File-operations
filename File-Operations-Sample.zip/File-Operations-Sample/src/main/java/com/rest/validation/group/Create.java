package com.rest.validation.group;

public interface Create {
}
