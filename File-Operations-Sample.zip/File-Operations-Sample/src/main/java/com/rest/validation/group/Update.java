package com.rest.validation.group;

public interface Update {
}
